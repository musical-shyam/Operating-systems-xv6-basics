3050 // System call numbers
3051 #define SYS_fork    1
3052 #define SYS_exit    2
3053 #define SYS_wait    3
3054 #define SYS_pipe    4
3055 #define SYS_read    5
3056 #define SYS_kill    6
3057 #define SYS_exec    7
3058 #define SYS_fstat   8
3059 #define SYS_chdir   9
3060 #define SYS_dup    10
3061 #define SYS_getpid 11
3062 #define SYS_sbrk   12
3063 #define SYS_sleep  13
3064 #define SYS_uptime 14
3065 #define SYS_open   15
3066 #define SYS_write  16
3067 #define SYS_mknod  17
3068 #define SYS_unlink 18
3069 #define SYS_link   19
3070 #define SYS_mkdir  20
3071 #define SYS_close  21
3072 
3073 
3074 
3075 
3076 
3077 
3078 
3079 
3080 
3081 
3082 
3083 
3084 
3085 
3086 
3087 
3088 
3089 
3090 
3091 
3092 
3093 
3094 
3095 
3096 
3097 
3098 
3099 
